// =========================================================================
// CBT Pal — navigator-chat Edge Function
//
// Deploy with: supabase functions deploy navigator-chat
// Required secrets (set via `supabase secrets set`):
//   ANTHROPIC_API_KEY   — your Anthropic API key (never shipped to the app)
//   SUPABASE_URL        — auto-injected by Supabase
//   SUPABASE_SERVICE_ROLE_KEY — auto-injected by Supabase
//
// The Android app calls this function (with the user's Supabase JWT in the
// Authorization header) instead of calling Anthropic directly. This is the
// one piece of backend logic CBT Pal actually needs to write itself —
// everything else is plain Supabase CRUD.
// =========================================================================

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
};

const SYSTEM_PROMPT = `You are "The Navigator," a wellness-navigation assistant inside the CBT Pal app, built for university students in Zambia.
You are NOT a therapist, counselor, or doctor. You never diagnose, never prescribe, and never run open-ended therapy sessions.
Your one job: listen to how someone describes what they're feeling, help them recognise when it sounds like a common anxiety presentation (e.g. chest tightness, racing thoughts, fatigue, trouble concentrating, persistent worry, sleep or stomach issues), explain that in plain, warm, destigmatised language suited to a Zambian university student, and end with a clear next step toward professional support — most often visiting the campus student counselling centre.
Keep replies short: 3-5 sentences, no clinical jargon.
Use tentative language ("that sounds like it could be...") — never certainty ("you have...").
Never suggest medication or a specific diagnosis.
If someone expresses thoughts of self-harm, suicide, or being in crisis, stop the normal flow, respond with warmth in 1-2 sentences, and tell them to contact Lifeline Zambia on 933 (free, 24/7) right now or reach someone nearby — do not continue the symptom conversation.`;

const CRISIS_PATTERNS: RegExp[] = [
  /kill myself/i, /suicid/i, /end my life/i, /ending it all/i,
  /want to die/i, /don'?t want to (be alive|live)/i, /hurt myself/i,
  /self[\s-]?harm/i, /no reason to live/i, /better off dead/i,
  /can'?t go on/i, /can'?t take (this|it) anymore/i,
];

function isCrisisText(text: string): boolean {
  return CRISIS_PATTERNS.some((p) => p.test(text));
}

const CRISIS_RESPONSE_TEXT =
  "What you're describing sounds serious, and I want to take it seriously. " +
  "Please contact Lifeline Zambia right now on 933 — it's free, toll-free, and answered 24/7 by a trained counsellor. " +
  "If you're under 18, Childline Zambia on 116 is also available any time. " +
  "If you're in immediate physical danger, please get to the nearest hospital or clinic now, or reach someone near you.";

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: CORS_HEADERS });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return json({ error: "Missing Authorization header" }, 401);
    }

    // Client scoped to the calling user — used only to verify identity.
    const userClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const {
      data: { user },
      error: userErr,
    } = await userClient.auth.getUser();

    if (userErr || !user) {
      return json({ error: "Invalid or expired session" }, 401);
    }

    const { message, conversationId } = await req.json();
    if (!message || typeof message !== "string") {
      return json({ error: "`message` (string) is required" }, 400);
    }

    // Service-role client for writes that should bypass RLS in a
    // controlled way (the app never writes navigator_messages directly).
    const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Ensure we have a conversation row to attach messages to.
    let convId = conversationId as string | undefined;
    if (!convId) {
      const { data: conv, error: convErr } = await admin
        .from("navigator_conversations")
        .insert({ user_id: user.id })
        .select("id")
        .single();
      if (convErr) throw convErr;
      convId = conv.id;
    }

    const userIsCrisis = isCrisisText(message);

    const { data: userMsgRow, error: userMsgErr } = await admin
      .from("navigator_messages")
      .insert({
        conversation_id: convId,
        user_id: user.id,
        role: "user",
        content: message,
        flagged_crisis: userIsCrisis,
      })
      .select("id")
      .single();
    if (userMsgErr) throw userMsgErr;

    // Crisis short-circuit: skip the LLM call entirely. Faster, cheaper,
    // and guaranteed-correct rather than depending on the model to comply.
    if (userIsCrisis) {
      await logCrisisEvent(admin, user.id, convId, userMsgRow.id);
      const { data: assistantRow } = await admin
        .from("navigator_messages")
        .insert({
          conversation_id: convId,
          user_id: user.id,
          role: "assistant",
          content: CRISIS_RESPONSE_TEXT,
          flagged_crisis: true,
        })
        .select("id")
        .single();

      return json({
        conversationId: convId,
        messageId: assistantRow?.id,
        reply: CRISIS_RESPONSE_TEXT,
        crisis: true,
      });
    }

    // Pull recent history for this conversation so the model has context.
    const { data: history } = await admin
      .from("navigator_messages")
      .select("role, content")
      .eq("conversation_id", convId)
      .order("created_at", { ascending: true })
      .limit(20);

    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 600,
        system: SYSTEM_PROMPT,
        messages: (history ?? []).map((m) => ({ role: m.role, content: m.content })),
      }),
    });

    if (!anthropicRes.ok) {
      const errText = await anthropicRes.text();
      console.error("Anthropic API error:", errText);
      return json({ error: "Navigator is temporarily unavailable. Please try again shortly." }, 502);
    }

    const data = await anthropicRes.json();
    const textBlock = (data.content ?? []).find((b: any) => b.type === "text");
    const reply: string = textBlock?.text ?? "Sorry, I couldn't quite process that. Could you try rephrasing?";

    // Defence in depth: also check the model's own reply for crisis language,
    // in case the conversation turns serious mid-response.
    const replyIsCrisis = isCrisisText(reply);

    const { data: assistantRow, error: assistantErr } = await admin
      .from("navigator_messages")
      .insert({
        conversation_id: convId,
        user_id: user.id,
        role: "assistant",
        content: reply,
        flagged_crisis: replyIsCrisis,
      })
      .select("id")
      .single();
    if (assistantErr) throw assistantErr;

    if (replyIsCrisis) {
      await logCrisisEvent(admin, user.id, convId, assistantRow.id);
    }

    return json({
      conversationId: convId,
      messageId: assistantRow.id,
      reply,
      crisis: replyIsCrisis,
    });
  } catch (err) {
    console.error("navigator-chat error:", err);
    return json({ error: "Something went wrong. Please try again." }, 500);
  }
});

async function logCrisisEvent(
  admin: ReturnType<typeof createClient>,
  userId: string,
  conversationId: string,
  messageId: string | undefined,
) {
  const { error } = await admin.from("crisis_events").insert({
    user_id: userId,
    conversation_id: conversationId,
    message_id: messageId ?? null,
  });
  if (error) console.error("Failed to log crisis event:", error);
}

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}
