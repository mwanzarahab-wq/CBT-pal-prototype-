-- =========================================================================
-- CBT Pal — Supabase schema
-- Run this in the Supabase SQL editor (or via the CLI: supabase db push).
-- Assumes Supabase Auth is enabled — auth.users already exists and every
-- row here is scoped to auth.uid().
-- =========================================================================

-- ---------------------------------------------------------------------
-- journal_entries — CBT thought records
-- ---------------------------------------------------------------------
create table journal_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  situation text not null,
  automatic_thought text not null,
  evidence_for text,
  evidence_against text,
  balanced_thought text,
  created_at timestamptz not null default now()
);

create index journal_entries_user_idx on journal_entries(user_id, created_at desc);

alter table journal_entries enable row level security;

create policy "journal: owner read" on journal_entries
  for select using (auth.uid() = user_id);

create policy "journal: owner insert" on journal_entries
  for insert with check (auth.uid() = user_id);

create policy "journal: owner update" on journal_entries
  for update using (auth.uid() = user_id);

create policy "journal: owner delete" on journal_entries
  for delete using (auth.uid() = user_id);

-- ---------------------------------------------------------------------
-- checkins — symptom recognition tool submissions
-- ---------------------------------------------------------------------
create table checkins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  symptoms jsonb not null default '[]'::jsonb,
  tone text not null check (tone in ('low', 'mid', 'high')),
  created_at timestamptz not null default now()
);

create index checkins_user_idx on checkins(user_id, created_at desc);

alter table checkins enable row level security;

create policy "checkins: owner read" on checkins
  for select using (auth.uid() = user_id);

create policy "checkins: owner insert" on checkins
  for insert with check (auth.uid() = user_id);

-- ---------------------------------------------------------------------
-- planner_days — one row per user per calendar day
-- ---------------------------------------------------------------------
create table planner_days (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null,
  tasks jsonb not null default '{}'::jsonb, -- e.g. {"sleep": true, "meals": false}
  created_at timestamptz not null default now(),
  unique (user_id, day)
);

create index planner_days_user_idx on planner_days(user_id, day desc);

alter table planner_days enable row level security;

create policy "planner: owner read" on planner_days
  for select using (auth.uid() = user_id);

create policy "planner: owner upsert" on planner_days
  for insert with check (auth.uid() = user_id);

create policy "planner: owner update" on planner_days
  for update using (auth.uid() = user_id);

-- ---------------------------------------------------------------------
-- navigator_conversations / navigator_messages — AI chat history
-- ---------------------------------------------------------------------
create table navigator_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table navigator_conversations enable row level security;

create policy "conversations: owner read" on navigator_conversations
  for select using (auth.uid() = user_id);

create policy "conversations: owner insert" on navigator_conversations
  for insert with check (auth.uid() = user_id);

create table navigator_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references navigator_conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  flagged_crisis boolean not null default false,
  created_at timestamptz not null default now()
);

create index navigator_messages_conv_idx on navigator_messages(conversation_id, created_at);

alter table navigator_messages enable row level security;

create policy "messages: owner read" on navigator_messages
  for select using (auth.uid() = user_id);

-- Inserts to navigator_messages are only ever made by the Edge Function
-- using the service-role key, which bypasses RLS — the app itself never
-- writes chat content directly, only reads it back.

-- ---------------------------------------------------------------------
-- crisis_events — minimal, privacy-conscious crisis log
-- Deliberately stores a flag + timestamp, not the triggering message text,
-- unless a future opt-in flow explicitly asks the user to share more for
-- a human follow-up. Keep this table lean.
-- ---------------------------------------------------------------------
create table crisis_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  conversation_id uuid references navigator_conversations(id) on delete set null,
  message_id uuid references navigator_messages(id) on delete set null,
  detected_at timestamptz not null default now(),
  resolved boolean not null default false,
  resolved_at timestamptz
);

create index crisis_events_user_idx on crisis_events(user_id, detected_at desc);
create index crisis_events_unresolved_idx on crisis_events(resolved) where resolved = false;

alter table crisis_events enable row level security;

create policy "crisis: owner read own" on crisis_events
  for select using (auth.uid() = user_id);

-- Inserts/updates to crisis_events are only made by the Edge Function via
-- the service-role key. No "owner insert" policy is defined on purpose —
-- a compromised client should not be able to fabricate or clear crisis
-- records.

-- ---------------------------------------------------------------------
-- Helper view: a counsellor-facing dashboard would query this through a
-- separate service-role-only connection, never through the public API.
-- ---------------------------------------------------------------------
create view crisis_events_unresolved as
  select id, user_id, detected_at
  from crisis_events
  where resolved = false
  order by detected_at asc;

-- Note: do NOT add a public RLS policy to this view. Access it only from
-- a trusted backend context (e.g. an admin dashboard authenticated with
-- the service-role key), never from the Android app.
