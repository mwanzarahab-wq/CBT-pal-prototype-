import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  Home, ListChecks, MessageCircle, PenLine, CalendarCheck, BookOpen,
  LifeBuoy, Send, Loader2, AlertTriangle, ChevronDown, ChevronRight, Plus, X,
  Sunrise, Phone, Clock, CheckCircle2, Circle, Sparkles, MapPin
} from "lucide-react";

/* ---------------------------------------------------------------------- */
/* Tokens                                                                  */
/* ---------------------------------------------------------------------- */

const COLORS = {
  night: "#232F4B",
  nightDeep: "#161E33",
  dawn: "#E98C73",
  dawnLight: "#F2A98F",
  gold: "#F0B860",
  sage: "#7FA08C",
  sageLight: "#E4ECE6",
  cream: "#F7F3EC",
  ink: "#2A2622",
  inkSoft: "#6B6356",
  line: "rgba(35,47,75,0.10)",
};

const FONT_IMPORT =
  "https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700;12..96,800&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap";

/* ---------------------------------------------------------------------- */
/* Storage helpers                                                         */
/* ---------------------------------------------------------------------- */

async function loadJSON(key, fallback) {
  try {
    const res = await window.storage.get(key, false);
    if (!res) return fallback;
    return JSON.parse(res.value);
  } catch (e) {
    return fallback;
  }
}

async function saveJSON(key, value) {
  try {
    await window.storage.set(key, JSON.stringify(value), false);
  } catch (e) {
    console.error("storage save failed", e);
  }
}

function todayKey(d = new Date()) {
  return d.toISOString().slice(0, 10);
}

/* ---------------------------------------------------------------------- */
/* Crisis detection                                                        */
/* ---------------------------------------------------------------------- */

const CRISIS_PATTERNS = [
  /kill myself/i, /suicid/i, /end my life/i, /ending it all/i,
  /want to die/i, /don'?t want to (be alive|live)/i, /hurt myself/i,
  /self[\s-]?harm/i, /no reason to live/i, /better off dead/i,
  /can'?t go on/i, /can'?t take (this|it) anymore/i,
];

function isCrisisText(text) {
  return CRISIS_PATTERNS.some((p) => p.test(text));
}

/* ---------------------------------------------------------------------- */
/* Shared content                                                          */
/* ---------------------------------------------------------------------- */

const SYMPTOMS = [
  { id: "chest", label: "Chest tightness or pain" },
  { id: "heart", label: "Racing or pounding heart" },
  { id: "sleep", label: "Trouble falling or staying asleep" },
  { id: "worry", label: "Persistent worry that won't switch off" },
  { id: "focus", label: "Difficulty concentrating" },
  { id: "stomach", label: "Stomach problems or nausea" },
  { id: "fatigue", label: "Fatigue with no clear cause" },
  { id: "headache", label: "Headaches" },
  { id: "onedge", label: "Irritability or feeling on edge" },
  { id: "avoid", label: "Avoiding classes or social situations" },
];

const LIBRARY_ARTICLES = [
  {
    title: "Why anxiety can feel physical",
    body:
      "Anxiety isn't only a feeling in your head — it's a whole-body response. When your nervous system reads a threat, real or not, it floods your body with stress hormones that speed up your heart, tighten your chest, and unsettle your stomach. That's why so many students end up at a clinic for chest pain or headaches with no physical cause: the body is reporting something real, even when the trigger is stress rather than illness. Recognising this link is often the first step toward getting the right kind of help.",
  },
  {
    title: "Anxiety isn't weakness",
    body:
      "It's common to read anxiety as personal failure — falling behind, snapping at friends, dreading class. None of that is a character flaw. Anxiety is a treatable medical condition with a clinical name and evidence-based care, not a measure of how strong or capable you are. Naming it accurately is what makes it possible to act on it instead of carrying it alone.",
  },
  {
    title: "What actually happens at a counselling appointment",
    body:
      "Most campus counselling centres start the same way: a conversation. A counsellor asks what's been going on, listens without judgement, and helps you make sense of it — there's no test you can fail and nothing is decided in one visit. Sessions are typically confidential. If you've never been, expect it to feel more like a structured conversation than a medical exam.",
  },
  {
    title: "Simple things that help day to day",
    body:
      "Small, repeatable habits make a real difference alongside professional support: a consistent sleep and wake time, short breaks between study blocks, eating at regular intervals, and a few minutes of slow breathing or a short walk when things feel like too much. The 5-4-3-2-1 grounding technique — naming 5 things you see, 4 you can touch, 3 you hear, 2 you smell, 1 you taste — can help bring a racing mind back to the present moment.",
  },
];

const SYSTEM_PROMPT = `You are "The Navigator," a wellness-navigation assistant inside the CBT Pal app, built for university students in Zambia.
You are NOT a therapist, counselor, or doctor. You never diagnose, never prescribe, and never run open-ended therapy sessions.
Your one job: listen to how someone describes what they're feeling, help them recognise when it sounds like a common anxiety presentation (e.g. chest tightness, racing thoughts, fatigue, trouble concentrating, persistent worry, sleep or stomach issues), explain that in plain, warm, destigmatised language suited to a Zambian university student, and end with a clear next step toward professional support — most often visiting the campus student counselling centre.
Keep replies short: 3-5 sentences, no clinical jargon.
Use tentative language ("that sounds like it could be...") — never certainty ("you have...").
Never suggest medication or a specific diagnosis.
If someone expresses thoughts of self-harm, suicide, or being in crisis, stop the normal flow, respond with warmth in 1-2 sentences, and tell them to contact Lifeline Zambia on 933 (free, 24/7) right now or reach someone nearby — do not continue the symptom conversation.`;

const RESOURCES = [
  {
    name: "Lifeline Zambia",
    number: "933",
    detail: "Free, toll-free, 24/7. Counselling for adults on mental health, stress, and crisis support.",
  },
  {
    name: "Childline Zambia",
    number: "116",
    detail: "Free, toll-free, 24/7. For callers under 18.",
  },
  {
    name: "UNICEF Zambia Youth Mental Health & Suicide Prevention Helpline",
    number: "+260 977 770 774",
    detail: "Monday–Friday, 9am–5pm. Mental health awareness and suicide-prevention support for young people.",
  },
];

/* ---------------------------------------------------------------------- */
/* Small UI atoms                                                          */
/* ---------------------------------------------------------------------- */

function DawnBar() {
  return (
    <div
      style={{
        height: 5,
        width: "100%",
        background:
          "linear-gradient(90deg,#161E33,#232F4B 25%,#6B5A8E 50%,#E98C73 78%,#F0B860 100%)",
        backgroundSize: "200% 100%",
        animation: "dawnshift 14s ease-in-out infinite",
      }}
    />
  );
}

function ScreenHeader({ icon: Icon, eyebrow, title, sub }) {
  return (
    <div style={{ padding: "22px 20px 16px" }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 6,
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 11,
          letterSpacing: "0.08em",
          textTransform: "uppercase",
          color: COLORS.dawn,
          fontWeight: 500,
        }}
      >
        {Icon && <Icon size={13} />}
        {eyebrow}
      </div>
      <h1
        style={{
          fontFamily: "'Bricolage Grotesque', sans-serif",
          fontWeight: 700,
          fontSize: 26,
          margin: "4px 0 2px",
          color: COLORS.night,
          letterSpacing: "-0.01em",
        }}
      >
        {title}
      </h1>
      {sub && (
        <p style={{ margin: 0, color: COLORS.inkSoft, fontSize: 13.5, lineHeight: 1.5 }}>
          {sub}
        </p>
      )}
    </div>
  );
}

function Card({ children, style }) {
  return (
    <div
      style={{
        background: "#fff",
        border: `1px solid ${COLORS.line}`,
        borderRadius: 16,
        padding: 16,
        boxShadow: "0 1px 2px rgba(35,47,75,0.04)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function PrimaryButton({ children, onClick, disabled, style, icon: Icon }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        width: "100%",
        padding: "13px 16px",
        borderRadius: 12,
        border: "none",
        background: disabled
          ? "#D8CFC2"
          : "linear-gradient(120deg,#E98C73,#F0B860)",
        color: disabled ? "#A39C8E" : COLORS.nightDeep,
        fontFamily: "'Inter', sans-serif",
        fontWeight: 700,
        fontSize: 14.5,
        cursor: disabled ? "not-allowed" : "pointer",
        transition: "transform 0.15s ease",
        ...style,
      }}
      onMouseDown={(e) => !disabled && (e.currentTarget.style.transform = "scale(0.98)")}
      onMouseUp={(e) => (e.currentTarget.style.transform = "scale(1)")}
    >
      {Icon && <Icon size={16} />}
      {children}
    </button>
  );
}

function CrisisCard() {
  return (
    <div
      style={{
        background: COLORS.nightDeep,
        borderRadius: 16,
        padding: 18,
        color: "#fff",
        border: `1px solid ${COLORS.gold}`,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <AlertTriangle size={18} color={COLORS.gold} />
        <span style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 700, fontSize: 15.5 }}>
          You matter — please reach out right now
        </span>
      </div>
      <p style={{ fontSize: 13.5, lineHeight: 1.55, color: "#E7E2D8", margin: "0 0 12px" }}>
        What you're describing sounds serious. Please contact someone immediately —
        a trained counsellor is ready to talk, free of charge.
      </p>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {RESOURCES.slice(0, 2).map((r) => (
          <div
            key={r.name}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              background: "rgba(255,255,255,0.07)",
              borderRadius: 10,
              padding: "10px 12px",
            }}
          >
            <Phone size={15} color={COLORS.gold} />
            <div>
              <div style={{ fontWeight: 600, fontSize: 13.5 }}>{r.name} — {r.number}</div>
              <div style={{ fontSize: 11.5, color: "#C9C3B6" }}>{r.detail}</div>
            </div>
          </div>
        ))}
      </div>
      <p style={{ fontSize: 11.5, color: "#A9A293", margin: "12px 0 0" }}>
        If you or someone near you is in immediate physical danger, go to the nearest
        hospital or clinic emergency department now.
      </p>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Screens                                                                  */
/* ---------------------------------------------------------------------- */

function HomeScreen({ go, stats }) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  return (
    <div>
      <div
        style={{
          margin: "0 20px 18px",
          borderRadius: 18,
          padding: "20px 18px",
          background: "linear-gradient(135deg,#232F4B,#4A4173 55%,#E98C73)",
          color: "#fff",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <Sunrise size={16} color={COLORS.gold} style={{ marginBottom: 8 }} />
        <div style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 700, fontSize: 20 }}>
          {greeting}.
        </div>
        <div style={{ fontSize: 13, color: "#E7E2D8", marginTop: 4, lineHeight: 1.5, maxWidth: 240 }}>
          One small check-in today is enough. You don't have to have it figured out.
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, padding: "0 20px 18px" }}>
        <Card style={{ flex: 1, textAlign: "center" }}>
          <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 22, fontWeight: 600, color: COLORS.night }}>
            {stats.journalCount}
          </div>
          <div style={{ fontSize: 11, color: COLORS.inkSoft }}>journal entries</div>
        </Card>
        <Card style={{ flex: 1, textAlign: "center" }}>
          <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 22, fontWeight: 600, color: COLORS.night }}>
            {stats.plannerStreak}
          </div>
          <div style={{ fontSize: 11, color: COLORS.inkSoft }}>day streak</div>
        </Card>
        <Card style={{ flex: 1, textAlign: "center" }}>
          <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 22, fontWeight: 600, color: COLORS.night }}>
            {stats.checkinCount}
          </div>
          <div style={{ fontSize: 11, color: COLORS.inkSoft }}>check-ins</div>
        </Card>
      </div>

      <div style={{ padding: "0 20px", display: "flex", flexDirection: "column", gap: 10 }}>
        {[
          { id: "checkin", icon: ListChecks, title: "Symptom check-in", sub: "See if what you're feeling lines up with anxiety" },
          { id: "navigator", icon: MessageCircle, title: "Talk to the Navigator", sub: "Describe how you're feeling, in your own words" },
          { id: "journal", icon: PenLine, title: "Write a thought record", sub: "Catch a thought, weigh the evidence, reframe it" },
          { id: "planner", icon: CalendarCheck, title: "Today's plan", sub: "Sleep, breaks, meals, and one self-care moment" },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => go(item.id)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 12,
              textAlign: "left",
              background: "#fff",
              border: `1px solid ${COLORS.line}`,
              borderRadius: 14,
              padding: "13px 14px",
              cursor: "pointer",
            }}
          >
            <div
              style={{
                width: 38, height: 38, borderRadius: 10, flexShrink: 0,
                background: COLORS.sageLight, display: "flex", alignItems: "center", justifyContent: "center",
              }}
            >
              <item.icon size={18} color={COLORS.night} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.ink }}>{item.title}</div>
              <div style={{ fontSize: 12, color: COLORS.inkSoft }}>{item.sub}</div>
            </div>
            <ChevronRight size={16} color={COLORS.inkSoft} />
          </button>
        ))}
      </div>

      <div style={{ padding: "18px 20px 8px" }}>
        <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em", color: COLORS.inkSoft, marginBottom: 8, fontWeight: 600 }}>
          Worth knowing
        </div>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 13.5, marginBottom: 4, color: COLORS.ink }}>
            {LIBRARY_ARTICLES[0].title}
          </div>
          <div style={{ fontSize: 12.5, color: COLORS.inkSoft, lineHeight: 1.5 }}>
            {LIBRARY_ARTICLES[0].body.slice(0, 110)}…
          </div>
          <button
            onClick={() => go("library")}
            style={{ marginTop: 8, border: "none", background: "none", color: COLORS.dawn, fontWeight: 600, fontSize: 12.5, padding: 0, cursor: "pointer" }}
          >
            Read more →
          </button>
        </Card>
      </div>
    </div>
  );
}

function CheckinScreen({ history, addCheckin, go }) {
  const [selected, setSelected] = useState([]);
  const [result, setResult] = useState(null);

  const toggle = (id) =>
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const submit = () => {
    const count = selected.length;
    const labels = SYMPTOMS.filter((s) => selected.includes(s.id)).map((s) => s.label);
    let tone;
    if (count >= 5) tone = "high";
    else if (count >= 2) tone = "mid";
    else tone = "low";
    const entry = { date: new Date().toISOString(), symptoms: labels, tone };
    setResult(entry);
    addCheckin(entry);
  };

  const reset = () => {
    setSelected([]);
    setResult(null);
  };

  if (result) {
    const copy = {
      high: "A lot of what you described — taken together — lines up with a common anxiety presentation. That doesn't mean something is wrong with you; it means your body has been carrying real stress.",
      mid: "A few of these can show up for lots of reasons, but together they're worth paying attention to. It may be worth talking it through with someone.",
      low: "What you've selected is fairly mild on its own. It's still okay to check in with someone if it's been bothering you.",
    };
    return (
      <div style={{ padding: "0 20px" }}>
        <Card style={{ marginBottom: 14 }}>
          <Sparkles size={18} color={COLORS.dawn} style={{ marginBottom: 8 }} />
          <p style={{ fontSize: 14, lineHeight: 1.6, color: COLORS.ink, margin: 0 }}>
            {copy[result.tone]}
          </p>
          {result.symptoms.length > 0 && (
            <div style={{ marginTop: 10, fontSize: 12, color: COLORS.inkSoft }}>
              You flagged: {result.symptoms.join(", ").toLowerCase()}.
            </div>
          )}
          <p style={{ fontSize: 11.5, color: COLORS.inkSoft, marginTop: 10, marginBottom: 0 }}>
            This is a screening reflection, not a diagnosis.
          </p>
        </Card>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <PrimaryButton onClick={() => go("navigator")} icon={MessageCircle}>
            Talk it through with the Navigator
          </PrimaryButton>
          <PrimaryButton
            onClick={() => go("support")}
            style={{ background: "#fff", border: `1px solid ${COLORS.line}`, color: COLORS.night }}
            icon={LifeBuoy}
          >
            See support options
          </PrimaryButton>
          <button onClick={reset} style={{ border: "none", background: "none", color: COLORS.inkSoft, fontSize: 12.5, padding: 8, cursor: "pointer" }}>
            Start a new check-in
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: "0 20px" }}>
      <p style={{ fontSize: 13, color: COLORS.inkSoft, marginTop: 0, lineHeight: 1.5 }}>
        Tap anything you've noticed over the last two weeks. There's no wrong answer.
      </p>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 18 }}>
        {SYMPTOMS.map((s) => {
          const active = selected.includes(s.id);
          return (
            <button
              key={s.id}
              onClick={() => toggle(s.id)}
              style={{
                padding: "9px 13px",
                borderRadius: 20,
                border: `1.5px solid ${active ? COLORS.night : COLORS.line}`,
                background: active ? COLORS.night : "#fff",
                color: active ? "#fff" : COLORS.ink,
                fontSize: 12.5,
                fontWeight: 500,
                cursor: "pointer",
              }}
            >
              {s.label}
            </button>
          );
        })}
      </div>
      <PrimaryButton onClick={submit} disabled={selected.length === 0}>
        See what this might mean
      </PrimaryButton>
      {history.length > 0 && (
        <div style={{ marginTop: 22 }}>
          <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em", color: COLORS.inkSoft, marginBottom: 8, fontWeight: 600 }}>
            Past check-ins
          </div>
          {history.slice(-3).reverse().map((h, i) => (
            <div key={i} style={{ fontSize: 12, color: COLORS.inkSoft, padding: "6px 0", borderBottom: `1px solid ${COLORS.line}` }}>
              {new Date(h.date).toLocaleDateString(undefined, { month: "short", day: "numeric" })} — {h.symptoms.length} symptom{h.symptoms.length !== 1 ? "s" : ""} flagged
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function NavigatorScreen() {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "Hi, I'm the Navigator. I'm not a therapist — think of me as a first step. Tell me what's been going on, in whatever words feel natural.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    const userMsg = { role: "user", content: text };
    setInput("");
    setMessages((m) => [...m, userMsg]);

    if (isCrisisText(text)) {
      setMessages((m) => [...m, { role: "crisis" }]);
      return;
    }

    setLoading(true);
    try {
      const history = [...messages, userMsg]
        .filter((m) => m.role === "user" || m.role === "assistant")
        .slice(-10)
        .map((m) => ({ role: m.role, content: m.content }));

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: history,
        }),
      });
      const data = await response.json();
      const textBlock = (data.content || []).find((b) => b.type === "text");
      const reply = textBlock ? textBlock.text : "Sorry, I couldn't quite process that. Could you try rephrasing?";
      if (isCrisisText(reply)) {
        setMessages((m) => [...m, { role: "assistant", content: reply }, { role: "crisis" }]);
      } else {
        setMessages((m) => [...m, { role: "assistant", content: reply }]);
      }
    } catch (e) {
      setMessages((m) => [
        ...m,
        { role: "assistant", content: "Something went wrong reaching the Navigator. Please try again in a moment." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: "0 20px", display: "flex", flexDirection: "column", gap: 12 }}>
        {messages.map((m, i) =>
          m.role === "crisis" ? (
            <CrisisCard key={i} />
          ) : (
            <div
              key={i}
              style={{
                alignSelf: m.role === "user" ? "flex-end" : "flex-start",
                maxWidth: "82%",
                background: m.role === "user" ? COLORS.night : "#fff",
                color: m.role === "user" ? "#fff" : COLORS.ink,
                border: m.role === "user" ? "none" : `1px solid ${COLORS.line}`,
                borderRadius: m.role === "user" ? "14px 14px 4px 14px" : "14px 14px 14px 4px",
                padding: "10px 13px",
                fontSize: 13.5,
                lineHeight: 1.5,
              }}
            >
              {m.content}
            </div>
          )
        )}
        {loading && (
          <div style={{ alignSelf: "flex-start", color: COLORS.inkSoft, fontSize: 12.5, display: "flex", alignItems: "center", gap: 6 }}>
            <Loader2 size={14} className="spin" /> thinking…
          </div>
        )}
        <div style={{ height: 8 }} />
      </div>
      <div style={{ padding: "10px 16px 16px", borderTop: `1px solid ${COLORS.line}`, display: "flex", gap: 8 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="What's been going on?"
          style={{
            flex: 1,
            border: `1px solid ${COLORS.line}`,
            borderRadius: 12,
            padding: "11px 13px",
            fontSize: 13.5,
            fontFamily: "'Inter', sans-serif",
            outline: "none",
          }}
        />
        <button
          onClick={send}
          disabled={loading || !input.trim()}
          style={{
            width: 42, height: 42, borderRadius: 12, border: "none", flexShrink: 0,
            background: "linear-gradient(120deg,#E98C73,#F0B860)",
            display: "flex", alignItems: "center", justifyContent: "center",
            cursor: loading ? "not-allowed" : "pointer",
          }}
        >
          <Send size={16} color={COLORS.nightDeep} />
        </button>
      </div>
    </div>
  );
}

function JournalScreen({ entries, addEntry }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ situation: "", thought: "", evidenceFor: "", evidenceAgainst: "", balanced: "" });
  const [expanded, setExpanded] = useState(null);

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = () => {
    if (!form.situation.trim() || !form.thought.trim()) return;
    addEntry({ ...form, date: new Date().toISOString() });
    setForm({ situation: "", thought: "", evidenceFor: "", evidenceAgainst: "", balanced: "" });
    setOpen(false);
  };

  const fields = [
    { k: "situation", label: "What happened?", ph: "e.g. Got back a low test score" },
    { k: "thought", label: "What thought popped up?", ph: "e.g. I'm going to fail this course" },
    { k: "evidenceFor", label: "Evidence that supports it", ph: "What makes this thought feel true?" },
    { k: "evidenceAgainst", label: "Evidence against it", ph: "What doesn't fit, or what would you tell a friend?" },
    { k: "balanced", label: "A more balanced thought", ph: "Something fairer, given the evidence" },
  ];

  if (open) {
    return (
      <div style={{ padding: "0 20px" }}>
        {fields.map((f) => (
          <div key={f.k} style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12.5, fontWeight: 600, color: COLORS.ink, display: "block", marginBottom: 5 }}>
              {f.label}
            </label>
            <textarea
              value={form[f.k]}
              onChange={(e) => update(f.k, e.target.value)}
              placeholder={f.ph}
              rows={2}
              style={{
                width: "100%", border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: 10,
                fontFamily: "'Inter', sans-serif", fontSize: 13, resize: "none", outline: "none", boxSizing: "border-box",
              }}
            />
          </div>
        ))}
        <div style={{ display: "flex", gap: 10 }}>
          <PrimaryButton onClick={save} disabled={!form.situation.trim() || !form.thought.trim()}>
            Save entry
          </PrimaryButton>
          <button onClick={() => setOpen(false)} style={{ border: "none", background: "none", color: COLORS.inkSoft, fontSize: 13, cursor: "pointer" }}>
            Cancel
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: "0 20px" }}>
      <button
        onClick={() => setOpen(true)}
        style={{
          width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          border: `1.5px dashed ${COLORS.dawn}`, borderRadius: 14, padding: 16, marginBottom: 18,
          background: "rgba(233,140,115,0.06)", color: COLORS.dawn, fontWeight: 600, fontSize: 13.5, cursor: "pointer",
        }}
      >
        <Plus size={16} /> New thought record
      </button>

      {entries.length === 0 && (
        <p style={{ fontSize: 13, color: COLORS.inkSoft, textAlign: "center" }}>
          No entries yet. Catching one thought is enough to start.
        </p>
      )}

      {entries.slice().reverse().map((e, i) => (
        <Card key={i} style={{ marginBottom: 10 }}>
          <button
            onClick={() => setExpanded(expanded === i ? null : i)}
            style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", background: "none", border: "none", padding: 0, cursor: "pointer" }}
          >
            <div style={{ textAlign: "left" }}>
              <div style={{ fontWeight: 600, fontSize: 13, color: COLORS.ink }}>{e.situation}</div>
              <div style={{ fontSize: 11.5, color: COLORS.inkSoft, fontFamily: "'IBM Plex Mono', monospace" }}>
                {new Date(e.date).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
              </div>
            </div>
            <ChevronDown size={16} color={COLORS.inkSoft} style={{ transform: expanded === i ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
          </button>
          {expanded === i && (
            <div style={{ marginTop: 10, fontSize: 12.5, color: COLORS.inkSoft, lineHeight: 1.6 }}>
              <div><b style={{ color: COLORS.ink }}>Thought:</b> {e.thought}</div>
              {e.evidenceFor && <div><b style={{ color: COLORS.ink }}>For:</b> {e.evidenceFor}</div>}
              {e.evidenceAgainst && <div><b style={{ color: COLORS.ink }}>Against:</b> {e.evidenceAgainst}</div>}
              {e.balanced && <div><b style={{ color: COLORS.ink }}>Balanced view:</b> {e.balanced}</div>}
            </div>
          )}
        </Card>
      ))}
    </div>
  );
}

const PLANNER_TASKS = [
  { id: "sleep", label: "Slept or rested on a regular schedule" },
  { id: "breaks", label: "Took a break between study blocks" },
  { id: "meals", label: "Ate at regular intervals" },
  { id: "selfcare", label: "Did one small self-care thing" },
  { id: "move", label: "Moved my body, even briefly" },
];

function PlannerScreen({ plannerData, toggleTask }) {
  const key = todayKey();
  const today = plannerData[key] || {};
  const done = PLANNER_TASKS.filter((t) => today[t.id]).length;

  const last7 = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const k = todayKey(d);
    const day = plannerData[k] || {};
    const count = PLANNER_TASKS.filter((t) => day[t.id]).length;
    return { k, count, label: d.toLocaleDateString(undefined, { weekday: "narrow" }) };
  }).reverse();

  return (
    <div style={{ padding: "0 20px" }}>
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: COLORS.ink }}>Today's progress</span>
          <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 13, color: COLORS.dawn, fontWeight: 600 }}>
            {done}/{PLANNER_TASKS.length}
          </span>
        </div>
        <div style={{ display: "flex", gap: 4 }}>
          {last7.map((d, i) => (
            <div key={i} style={{ flex: 1, textAlign: "center" }}>
              <div
                style={{
                  height: 28, borderRadius: 6, marginBottom: 4,
                  background: d.count === 0 ? COLORS.sageLight : `rgba(233,140,115,${0.25 + d.count * 0.15})`,
                }}
              />
              <span style={{ fontSize: 9.5, color: COLORS.inkSoft }}>{d.label}</span>
            </div>
          ))}
        </div>
      </Card>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {PLANNER_TASKS.map((t) => {
          const checked = !!today[t.id];
          return (
            <button
              key={t.id}
              onClick={() => toggleTask(key, t.id)}
              style={{
                display: "flex", alignItems: "center", gap: 10, textAlign: "left",
                background: "#fff", border: `1px solid ${COLORS.line}`, borderRadius: 12,
                padding: "12px 13px", cursor: "pointer",
              }}
            >
              {checked ? <CheckCircle2 size={19} color={COLORS.sage} /> : <Circle size={19} color={COLORS.line} />}
              <span style={{ fontSize: 13.5, color: checked ? COLORS.inkSoft : COLORS.ink, textDecoration: checked ? "line-through" : "none" }}>
                {t.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function LibraryScreen() {
  const [open, setOpen] = useState(0);
  return (
    <div style={{ padding: "0 20px" }}>
      {LIBRARY_ARTICLES.map((a, i) => (
        <Card key={i} style={{ marginBottom: 10 }}>
          <button
            onClick={() => setOpen(open === i ? -1 : i)}
            style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", background: "none", border: "none", padding: 0, cursor: "pointer" }}
          >
            <span style={{ fontWeight: 600, fontSize: 14, color: COLORS.ink, textAlign: "left" }}>{a.title}</span>
            <ChevronDown size={16} color={COLORS.inkSoft} style={{ transform: open === i ? "rotate(180deg)" : "none", transition: "transform 0.2s", flexShrink: 0, marginLeft: 8 }} />
          </button>
          {open === i && (
            <p style={{ fontSize: 13, color: COLORS.inkSoft, lineHeight: 1.6, marginTop: 10, marginBottom: 0 }}>
              {a.body}
            </p>
          )}
        </Card>
      ))}
    </div>
  );
}

function SupportScreen() {
  return (
    <div style={{ padding: "0 20px" }}>
      <Card style={{ marginBottom: 14, background: COLORS.sageLight, border: "none" }}>
        <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
          <MapPin size={18} color={COLORS.night} style={{ flexShrink: 0, marginTop: 2 }} />
          <div>
            <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.night }}>UNZA Student Counselling Centre</div>
            <div style={{ fontSize: 12.5, color: COLORS.inkSoft, lineHeight: 1.5, marginTop: 3 }}>
              Visit in person at the Great East Road Campus, Student Affairs area.
              Sessions are typically confidential and free for registered students —
              add the centre's direct phone line here once confirmed.
            </div>
          </div>
        </div>
      </Card>

      <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em", color: COLORS.inkSoft, marginBottom: 8, fontWeight: 600 }}>
        Free national helplines
      </div>
      {RESOURCES.map((r) => (
        <Card key={r.name} style={{ marginBottom: 10 }}>
          <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
            <Phone size={16} color={COLORS.dawn} style={{ flexShrink: 0, marginTop: 2 }} />
            <div>
              <div style={{ fontWeight: 700, fontSize: 13.5, color: COLORS.ink }}>
                {r.name} <span style={{ color: COLORS.dawn }}>· {r.number}</span>
              </div>
              <div style={{ fontSize: 12, color: COLORS.inkSoft, marginTop: 2 }}>{r.detail}</div>
            </div>
          </div>
        </Card>
      ))}

      <div style={{ display: "flex", gap: 8, alignItems: "flex-start", padding: "12px 4px", color: COLORS.inkSoft }}>
        <Clock size={14} style={{ flexShrink: 0, marginTop: 2 }} />
        <p style={{ fontSize: 11.5, lineHeight: 1.5, margin: 0 }}>
          If you or someone near you is in immediate physical danger, go to the nearest
          hospital or clinic emergency department right away rather than waiting for a callback.
        </p>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Shell                                                                    */
/* ---------------------------------------------------------------------- */

const TABS = [
  { id: "home", label: "Home", icon: Home },
  { id: "checkin", label: "Check-in", icon: ListChecks },
  { id: "navigator", label: "Navigator", icon: MessageCircle },
  { id: "journal", label: "Journal", icon: PenLine },
  { id: "planner", label: "Planner", icon: CalendarCheck },
  { id: "library", label: "Learn", icon: BookOpen },
  { id: "support", label: "Support", icon: LifeBuoy },
];

const TAB_META = {
  home: { eyebrow: "CBT Pal", title: "Welcome back", icon: Sunrise },
  checkin: { eyebrow: "Symptom check-in", title: "How's your body been?", icon: ListChecks },
  navigator: { eyebrow: "AI Navigator", title: "The Navigator", icon: MessageCircle },
  journal: { eyebrow: "Thought record", title: "Journal", icon: PenLine },
  planner: { eyebrow: "Daily structure", title: "Wellness planner", icon: CalendarCheck },
  library: { eyebrow: "Psychoeducation", title: "Learn", icon: BookOpen },
  support: { eyebrow: "Crisis & referrals", title: "Support", icon: LifeBuoy },
};

export default function CBTPalApp() {
  const [screen, setScreen] = useState("home");
  const [loaded, setLoaded] = useState(false);
  const [journalEntries, setJournalEntries] = useState([]);
  const [checkinHistory, setCheckinHistory] = useState([]);
  const [plannerData, setPlannerData] = useState({});

  useEffect(() => {
    (async () => {
      const [j, c, p] = await Promise.all([
        loadJSON("journal-entries", []),
        loadJSON("checkin-history", []),
        loadJSON("planner-data", {}),
      ]);
      setJournalEntries(j);
      setCheckinHistory(c);
      setPlannerData(p);
      setLoaded(true);
    })();
  }, []);

  const addEntry = useCallback((entry) => {
    setJournalEntries((prev) => {
      const next = [...prev, entry];
      saveJSON("journal-entries", next);
      return next;
    });
  }, []);

  const addCheckin = useCallback((entry) => {
    setCheckinHistory((prev) => {
      const next = [...prev, entry];
      saveJSON("checkin-history", next);
      return next;
    });
  }, []);

  const toggleTask = useCallback((dateKey, taskId) => {
    setPlannerData((prev) => {
      const day = { ...(prev[dateKey] || {}) };
      day[taskId] = !day[taskId];
      const next = { ...prev, [dateKey]: day };
      saveJSON("planner-data", next);
      return next;
    });
  }, []);

  const streak = (() => {
    let s = 0;
    for (let i = 0; i < 60; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const day = plannerData[todayKey(d)];
      if (day && Object.values(day).some(Boolean)) s++;
      else break;
    }
    return s;
  })();

  const meta = TAB_META[screen];

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(160deg,#1B2238,#3A3158 45%,#5A4A6E)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px 12px",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <style>{`
        @import url('${FONT_IMPORT}');
        @keyframes dawnshift { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        .spin { animation: spin 1s linear infinite; }
        @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        * { box-sizing: border-box; }
        input::placeholder, textarea::placeholder { color: #B4ACA0; }
      `}</style>

      <div
        style={{
          width: 390,
          height: 800,
          maxHeight: "94vh",
          background: COLORS.cream,
          borderRadius: 36,
          overflow: "hidden",
          boxShadow: "0 30px 70px rgba(0,0,0,0.45)",
          display: "flex",
          flexDirection: "column",
          position: "relative",
          border: "8px solid #14101D",
        }}
      >
        <DawnBar />

        {!loaded ? (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: COLORS.inkSoft, fontSize: 13 }}>
            <Loader2 size={18} className="spin" style={{ marginRight: 8 }} /> loading CBT Pal…
          </div>
        ) : (
          <>
            {screen !== "navigator" && (
              <ScreenHeader icon={meta.icon} eyebrow={meta.eyebrow} title={meta.title} />
            )}
            {screen === "navigator" && (
              <ScreenHeader icon={meta.icon} eyebrow={meta.eyebrow} title={meta.title}
                sub="Not a therapist. A first step toward one." />
            )}

            <div style={{ flex: 1, overflowY: screen === "navigator" ? "hidden" : "auto", display: "flex", flexDirection: "column", paddingBottom: screen === "navigator" ? 0 : 18 }}>
              {screen === "home" && (
                <HomeScreen
                  go={setScreen}
                  stats={{ journalCount: journalEntries.length, plannerStreak: streak, checkinCount: checkinHistory.length }}
                />
              )}
              {screen === "checkin" && <CheckinScreen history={checkinHistory} addCheckin={addCheckin} go={setScreen} />}
              {screen === "navigator" && <NavigatorScreen />}
              {screen === "journal" && <JournalScreen entries={journalEntries} addEntry={addEntry} />}
              {screen === "planner" && <PlannerScreen plannerData={plannerData} toggleTask={toggleTask} />}
              {screen === "library" && <LibraryScreen />}
              {screen === "support" && <SupportScreen />}
            </div>
          </>
        )}

        <div
          style={{
            display: "flex",
            borderTop: `1px solid ${COLORS.line}`,
            background: "#fff",
            padding: "8px 4px",
            flexShrink: 0,
          }}
        >
          {TABS.map((t) => {
            const active = screen === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setScreen(t.id)}
                style={{
                  flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3,
                  background: "none", border: "none", padding: "6px 2px", cursor: "pointer",
                  color: active ? COLORS.dawn : COLORS.inkSoft,
                }}
              >
                <t.icon size={17} strokeWidth={active ? 2.4 : 2} />
                <span style={{ fontSize: 9, fontWeight: active ? 700 : 500 }}>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
